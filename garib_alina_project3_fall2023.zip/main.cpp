//
// Created by alina on 11/16/2023.
//
#include <iostream>
#include <SFML/Graphics.hpp>
#include "TextureManager.h"
#include "welcome.h"
using namespace std;


int main()
{
    welcomeWindow welcome_window;
    welcome_window.drawWelcomeWindow();


    return 0;
}