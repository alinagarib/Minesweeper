Name: Alina Garib
Section: Maeson 3-5pm
UFL email: agarib@ufl.edu
System: Windows
Compiler: CLion/CMake-build-debug
SFML version: SFML2.5.1/MinGW 7.3.0 64-bit
IDE: CLion
Other notes: the manual said that the config file was called board_config, but in the zip file we were
given for the project it was just called config, so I read from a file called "config"